from setuptools import setup, find_packages

setup(
    name="cheese",             # package name
    version="0.1.0",           # version
    packages=find_packages(),  # automatically find packages
    install_requires=[],       # any dependencies
    description="A small cheese module",
    author="fela14",
    author_email="k.fakeye@yahoo.com",
    url="https://github.com/fela14/Cheese",  # repo URL
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
